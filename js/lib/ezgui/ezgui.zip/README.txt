Thank you for downloading EZGUI :)


This package contain :

 * Main EZGUI library under js\EZGUI.js and TypeScript declaration files

 * Themes shiped with EZGUI, those will be enhanced in future version with more components skins and fonts.

 * two demos showing how to use EZGUI (application demo and game demo) those will be updated in future versions.


please note that to run those examples you'll need a local web server 



Suggestions and feedbacks are welcome.
also feel free to report issues via Github repository at https://github.com/Ezelia/EZGUI


Enjoy